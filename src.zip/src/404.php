<?php
get_header();

require 'layouts/hero-404/hero-404.php';
get_footer();