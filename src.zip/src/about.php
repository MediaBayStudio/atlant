<?php
/*
Template name: О компании
*/
get_header();

require 'layouts/about-hero/about-hero.php';
require 'layouts/about-features/about-features.php';
require 'layouts/about-consult/about-consult.php';
get_footer();