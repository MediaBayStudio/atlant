<?php
/*
Template name: Контакты
*/
get_header();

require 'layouts/contacts-hero/contacts-hero.php';
require 'layouts/contacts-feedback/contacts-feedback.php';
get_footer();