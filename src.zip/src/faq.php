<?php
/*
Template name: Вопрос-ответ
*/
get_header();

require 'layouts/faq-hero/faq-hero.php';
get_footer();