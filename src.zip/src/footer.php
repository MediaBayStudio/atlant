<?php
wp_footer();

require 'layouts/mobile-menu/mobile-menu.php';
require 'layouts/overlay/overlay.php';
require 'layouts/faq-popup/faq-popup.php';
require 'layouts/review-popup/review-popup.php';
require 'layouts/thanks-popup/thanks-popup.php';

?>
	</body>
</html>