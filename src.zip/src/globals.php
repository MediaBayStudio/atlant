<?php
  $template_directory = get_template_directory_uri();
  $site_url = site_url();
  $is_front_page = is_front_page();
  
  $address = get_option( 'contacts_address' );
  $tel_people = get_option( 'contacts_tel_people' );
  $tel_people_dry = preg_replace( '/\s/', '', $tel_people );
  $tel_company = get_option( 'contacts_tel_company' );
  $tel_company_dry = preg_replace( '/\s/', '', $tel_company );
  $phones = [ $tel_people, $tel_company ];
  $phones_dry = [ $tel_people_dry, $tel_company_dry ];
  $phones_sign = [ 'Для физических лиц', 'Для юр. лиц и партнеров' ];
  $email = get_option( 'contacts_email' );
  $whatsapp = get_option( 'contacts_whatsapp' );
// $img_placeholder_url = 'url(' . get_template_directory_uri() . '/img/img-placeholder.svg)';
  // $is_category = is_category();
  // $is_front_page = is_front_page();
  // $queried_object = get_queried_object();
  // $categories = get_categories( ['hide_empty' => 0] );