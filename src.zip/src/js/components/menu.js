// menu = new MobileMenu('.menu', {
//   openButton: '.burger',
//   closeButtons: '.burger',
//   overlay: '.overlay',
//   toRight: true,
//   fixHeader: '.hdr'
// });