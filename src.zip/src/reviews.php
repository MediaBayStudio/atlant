<?php
/*
Template name: Отзывы
*/
get_header();

require 'layouts/reviews-hero/reviews-hero.php';
get_footer();